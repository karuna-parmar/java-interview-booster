# Day 1: Core Java Fundamentals

## Topics Covered
- OOP: Abstraction, Encapsulation, Inheritance, Polymorphism
- Java Memory Model: Stack vs Heap, GC, References
- String Interning, Immutability, StringBuilder vs String

## Interview Questions
1. What are the four pillars of OOP?
2. Why is String immutable in Java?
3. Difference between == and .equals()?
4. Stack vs Heap memory?
5. StringBuilder vs StringBuffer?

## Coding Exercises
- OOPConceptsDemo.java
- StringPoolCheck.java
- StringBuilderVsStringPerformance.java
