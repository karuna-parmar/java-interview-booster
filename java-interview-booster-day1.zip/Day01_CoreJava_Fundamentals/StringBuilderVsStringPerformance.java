public class StringBuilderVsStringPerformance {
    public static void main(String[] args) {
        int iterations = 10000;

        // Using String
        long startTime1 = System.nanoTime();
        String s = "";
        for (int i = 0; i < iterations; i++) {
            s += "a";
        }
        long endTime1 = System.nanoTime();
        long durationString = (endTime1 - startTime1) / 1_000_000;
        System.out.println("Time taken using String: " + durationString + " ms");

        // Using StringBuilder
        long startTime2 = System.nanoTime();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < iterations; i++) {
            sb.append("a");
        }
        long endTime2 = System.nanoTime();
        long durationSB = (endTime2 - startTime2) / 1_000_000;
        System.out.println("Time taken using StringBuilder: " + durationSB + " ms");
    }
}
